# Directorio Femasport

Aplicación React interna para visualizar un directorio privado de contactos.

## Acceso

- Usuario: `femasport`
- Contraseña: `DIRFEMA**`

## Instalación

```bash
npm install
npm start
```

## Despliegue

Sube este proyecto a GitHub y luego despliega con [Vercel](https://vercel.com).